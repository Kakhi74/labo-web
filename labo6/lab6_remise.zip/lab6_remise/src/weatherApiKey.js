export const weatherApiKey = "679e1f13426b4545b4eca192cd7b9b5a";
